class BaseFactor(object):
    """
    Base class for Factors. Any Factor implementation should inherit this class.
    """
    def __init__(self):
        pass
